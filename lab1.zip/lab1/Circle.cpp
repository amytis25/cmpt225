/*
 * Circles.cpp
 *
 * Class Description: class represeting 2 circles in two-dimensional cartiesien space.
 *
 * Class Invariant: 'Radius' > '0.0'
 * 
 * Author: Amytis Saghafi , asa414@sfu.ca
 * Modified on: Jan. 2023
 */
#include "Circle.h"
#include <cctype>
#include <sstream>
#include <iostream>
#include <cmath>

using namespace std;
Circle::Circle (){

}
Circle::Circle (){
    x= 0.0;
    y= 0.0;
    radius = 10.0;
    
};

int Circle::getX (){//returns the circle's centre x coordinate
    return x;
}
int Circle::getY (){//returns the circle's centre y coordinate
    return y;
}
int Circle::setX (int X_u){
    X_u = x;
    return x;
}
int Circle::setY (int Y_u){
    Y_u = y;
    return y;
}
double Circle::getRadius(){//returns the circle's radius
    return radius;
}
void Circle::move ( int horiz , int vert){ 
    //moves the circle the given horizontal and vertical distances
    //(therefore changing its x and y member attributes)
    x = x + horiz;
    y = y + vert;
}
void Circle::setRadius (double r){ //changes the circle's radius to r, or to 10.0 if r is invalid
    if (r> 0.0){
        radius = r;
    }else {
        radius = 10.0;
    }
}


double Circle::computeArea(){
    //computes and returns the circle's area
    double area = 0.0;
    area = PI * radius ^ 2;

}
void Circle::displayCircle(){
    //displays the circle's member attributes like this:
    //x = 0, y = 11, radius =0.
    cout << "x = " << getX << ", y = " << getY << ", radius = " << getRadius << endl;

}
bool Circle::intersect(Circle C){
    //returns true if c intersects the calling circle

}
